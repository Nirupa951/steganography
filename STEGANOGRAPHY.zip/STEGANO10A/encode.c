#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    // Find the size of secret file data
    fseek(fptr,0,SEEK_END);
    uint size=ftell(fptr);
    rewind(fptr);
    return size;
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    char *ptr;
    // Step 1 : check argv[2] is having .bmp or not
    ptr=strstr(argv[2],".bmp");
    //  By using the strtr function check substring is present or not char* ptr = strstr(argv[2] , ".bmp")
    
    //  if present make sure it's conatin only .bmp by using the strcmp(ptr , ".bmp") function
    // true : store into the structure member encInfo->src_image_fname = argv[2];
    if(ptr!=NULL&&strcmp(ptr,".bmp")==0)
    {
        encInfo->src_image_fname=argv[2];
    }
    //  false : print the error message and return e_failure
    else{
        return e_failure;
    }


    // Step 2 : check argv[3] is having .txt or not
    ptr=strrchr(argv[3],'.');
    // By using the strtr function check substring is present or not char* ptr = strstr(argv[3] , ".txt")
    // if present make sure it's conatin only .bmp by using the strcmp(ptr , ".txt") function
     if(ptr!=NULL)
    {
        encInfo->secret_fname=argv[3];
    }
    // true : store into the structure member encInfo->secret_fname = argv[3];
    
    //  false : print the error message and return e_failure
    else{
        printf("Error message");
        return e_failure;
    }

    // Step 3 : check argv[4] != NULL false : got to the step 4
    // true  : By using the strtr function check substring is present or not char* ptr = strstr(argv[4] , ".bmp")
    // if present make sure it's conatin only .bmp by using the strcmp(ptr , ".bmp") function
    // true : store into the structure member encInfo->dest_image_fname = argv[4];
    //  false : print the error message and return e_failure
    if(argv[4]!=NULL)
    {
        ptr=strstr(argv[4],".bmp");
        if(ptr!=NULL && strcmp(ptr,".bmp")==0)
        {
            encInfo->dest_image_fname=argv[4];
        }
        else{
            printf("ERROR:destination image file");
            return e_failure;
        }
    }

    // Step 4 : when argv[4] == NULL
    // store by default name into structure member encInfo->dest_image_fname = "default..bmp";

    // return e_success
    else{
        encInfo->dest_image_fname="default.bmp";
    }
    return e_success;
}

Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_dest_image = fopen(encInfo->dest_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_dest_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->dest_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    // Step1 : encinfo->image_capacity =call the get_image_size_for_bmp(encinfo->fptr_src_fname);
    encInfo->image_capacity=get_image_size_for_bmp(encInfo->fptr_src_image);
    // Step 2 : encinfo->size_secret_file=  get_file_size(encinfo->fptr_secret_fname)
    encInfo->size_secret_file=  get_file_size(encInfo->fptr_secret);
    // Step3 : encinfo->image_capacity > 16 + 32 + 32 + 32 + (encinfo->size_secret_file * 8)
    if(encInfo->image_capacity>(16+32+32+32+(encInfo->size_secret_file*8)))
    {
    
    //  true : return e_success
    return e_success;
    }
    else{

    //  false : return e_failure
    return e_failure;
}
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    // Step1 : rewind the fptr_src_image
    rewind(fptr_src_image);
    // Step 2 :char image_buffer[54];
    char image_buffer[54];
    //  Step 3 : Read 54 bytes of data and store into the image_buffer
    fread(image_buffer,54,1,fptr_src_image);
    // Step4 : Write the image_buffer into the destination image
    fwrite(image_buffer,54,1,fptr_dest_image);
    // Step 4 : check the offset of both file pointer
    if(ftell(fptr_src_image)==54&&ftell(fptr_dest_image)==54)
    {
    // true : return e_success;
    return e_success;
    }
    //  false : return e_failure
    else{
        return e_failure;
    }
}
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    // Step 1 ; char imageBuffer[8]
    char imageBuffer[8];
    // Step 2 : Generate the lopp upto the length of the magic_string
    for(int i=0;i<strlen(magic_string);i++)
    {
    // Step 3 : Read 8 bytes of data from src image and store in the image_buffer
    fread(imageBuffer,8,1,encInfo->fptr_src_image);
    // Step 4 : Call the enconde_byte_to_lsb(magic_string[i] , image_buffer)
    encode_byte_to_lsb(magic_string[i] , imageBuffer);
    // Step 5 : Write imagebuffer in to the destination image
    fwrite(imageBuffer,8,1,encInfo->fptr_dest_image);
    }
    // Repeat the process untill the loop gets terminates
    if(ftell(encInfo->fptr_src_image)==(54+strlen(magic_string)*8)&&ftell(encInfo->fptr_dest_image)==(54+strlen(magic_string)*8))
    {
        return e_success;
    }

    // Step 6  check the offset of both file pointer
    // true : return e_success;
    //  false : return e_failure
    else{
        return e_failure;
    }
}
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    // Step 1 : char imagBuffer[32];
    char imagBuffer[32];
    //  Step 2 : Read 32 bytes of data from src image and store in the image_buffer
    fread(imagBuffer,32,1,encInfo->fptr_src_image);
    //  Step 3 : Call the enconde_size_to_lsb(size, image_buffer)
    encode_size_to_lsb(size,imagBuffer);
    //  Step 4 : Write imagebuffer in to the destination image
    fwrite(imagBuffer,32,1,encInfo->fptr_dest_image);

    // Step 5 : check the offset of both file pointer
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))
    {

    // true : return e_success;
    return e_success;
    }
    //  false : return e_failure
    else{
        return e_failure;

    }
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    // Step 1 ; char imageBuffer[8]
    char imageBuffer[8];
    // Step 2 : Generate the lopp upto the length of the file_extn
    for(int i=0;i<strlen(file_extn);i++)
    {

    // Step 3 : Read 8 bytes of data from src image and store in the image_buffer
    fread(imageBuffer,8,1,encInfo->fptr_src_image);
    // Step 4 : Call the enconde_byte_to_lsb(file_extn[i] , image_buffer)
    encode_byte_to_lsb(file_extn[i] , imageBuffer);
    // Step 5 : Write imagebuffer in to the destination image
    fwrite(imageBuffer,8,1,encInfo->fptr_dest_image);
    // Repeat the process untill the loop gets terminates
    }

    // Step 6  check the offset of both file pointer
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))
    // true : return e_success;
    {
        return e_success;
    }
    //  false : return e_failure
    else{
        return e_failure;
    }


}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    // Step 1 : char imagBuffer[32];
    char imageBuffer[32];
    //  Step 2 : Read 32 bytes of data from src image and store in the image_buffer
    fread(imageBuffer,32,1,encInfo->fptr_src_image);
    //  Step 3 : Call the enconde_size_to_lsb(file_size, image_buffer)
    encode_size_to_lsb(file_size, imageBuffer);
    //  Step 4 : Write imagebuffer in to the destination image
    fwrite(imageBuffer,32,1,encInfo->fptr_dest_image);

    // Step 5 : check the offset of both file pointer
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))
    {
        return e_success;
    }
    // true : return e_success;
    //  false : return e_failure
    else{
        return e_failure;
    }
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    // Step1 :rewind the secret file pointer
    rewind(encInfo->fptr_secret);

    // Step2 : char file_data[encinfo->secre_file_size];
    char file_data[encInfo->size_secret_file];
    // Step 3 : Read the secret data from secret.txt and store inside file_data
    fread(file_data,encInfo->size_secret_file,1,encInfo->fptr_secret);

    // char image_buffer[54]   ;
    char image_buffer[54];
    // Step 4 : Generate the loop upto the length of the encinfo->secret_file_size
    for(int i=0;i<encInfo->size_secret_file;i++)
    {
    // Step 5 : Read 8 bytes of data from src image and store in the image_buffer
    fread(image_buffer,8,1,encInfo->fptr_src_image);
    // Step 6 : Call the enconde_byte_to_lsb(file_data[i] , image_buffer)
    encode_byte_to_lsb(file_data[i],image_buffer);
    // Step 7 : Write imagebuffer in to the destination image
    fwrite(image_buffer,8,1,encInfo->fptr_dest_image);
    }
    // Repeat the process untill the loop gets terminates

    // Step 8  check the offset of both file pointer
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))
    {
    // true : return e_success;
    return e_success;}
    //  false : return e_failure
    else{
        return e_failure;
    }
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    // Step 1 : Generate the loop for 8 times
    // Step 2 : Get the one bit from data
    // Step 3 : Clear the lsb bit of imageBuffer[i]
    // Step 4 : Set the get bit in a lsb of imagebuffer[i]
    // Repeat the process until the loop get's terminated
     int i;
   for(i=0;i<8;i++)
   {
   int bit=(data>>(7-i)&1);
   image_buffer[i]&=0XFE;
   image_buffer[i]|=bit;
}
return e_success;
}

Status encode_size_to_lsb(int size, char *imageBuffer)
{
    int i;
    // Step 1 : Generate the loop for 32 times
    for(i=0;i<32;i++)
    {
    // Step 2 : Get the one bit from size
    int bit=(size>>(31-i)&1);
    // Step 3 : Clear the lsb bit of imageBuffer[i]
    imageBuffer[i]&=0xFE;
    // Step 4 : Set the get bit in a lsb of imagebuffer[i]
    imageBuffer[i]|=bit;
    // Repeat the process until the loop get's terminated
    }
    return e_success;

}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    // Copy the remaining the data from source to destination
    char ch;
    while(fread(&ch,1,1,fptr_src)==1)
    {
      fwrite(&ch,1,1,fptr_dest); 
    }
    return e_success;
}

Status do_encoding(EncodeInfo *encInfo)
{
    // Step1 : Call the open_files(encInfo) == e_success
    // true : print the prompt message , go to the step 2 ;
    //  false : print the error return e_failure
    if(open_files(encInfo)==e_success)
    {
        printf("files opened successfully\n");
    }
    else{
        printf("unable to open files\n");
        return e_failure;
    }

    // Step 2 : call the check_capacity(encinfo)== e_success
    // true : print the prompt message , go to the step 3 ;
    //  false : print the error return e_failure
    if(check_capacity(encInfo)==e_success)
    {
        printf("Image have enough capacity\n");
    }
    else{
        printf("ERROR: insufficient image capacity\n");
        return e_failure;
    }

    // Step 3 : call the copy_bmp_header(filepointers)== e_success
    // true : print the prompt message , go to the step 4 ;
    //  false : print the error return e_failure
    if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_dest_image)==e_success)
    {
        printf("Bmp header encoded successfully\n");
    }
    else{
        printf("ERROR: failed to copy Bmp header\n");
        return e_failure;
    }

    // Step 4 : encode_magic_string(Magic_string , encInfo) ==e_success
    // true : print the prompt message , go to the step 5 ;
    //  false : print the error return e_failure
    if(encode_magic_string(MAGIC_STRING , encInfo) ==e_success)
    {
    printf("magic string encoded successfully\n");}
    else
    {
        printf("ERROR:failed to encode magic string\n");
        return e_failure;
}
    // Step 5 : Store the secret file extn (encinfo ->extn_secret_file)
    strcpy(encInfo->extn_secret_file,strstr(encInfo->secret_fname,"."));

    // Step 6 : encode_secret_file_extn_size(secret_file_extn_size , encinfo)  ==e_success
    // true : print the prompt message , go to the step 7 ;
    //  false : print the error return e_failure
    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file),encInfo)==e_success)
    {
        printf("extension encoded successfully\n");
    }
    else{
        printf("ERROR:not encoded extension\n");
        return e_failure;
    }

    // Step 7 : encode_secret_file_extn(encinfo ->extn_secret_file , encinfo) ==e_success
    // true : print the prompt message , go to the step 8 ;
    //  false : print the error return e_failure
    if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo)==e_success)
    {
        printf("extension encoded successfully\n");
    }
    else{
        printf("Error:failed to encode extension\n");
        return e_failure;
    }

    // Step 8 : encode_secret_file_size(encinfo ->secret_file_size , encinfo) ==e_success
    // true : print the prompt message , go to the step 9 ;
    //  false : print the error return e_failure
    if(encode_secret_file_size(encInfo->size_secret_file,encInfo)==e_success)
    {
        printf("secret file size encoded successfully\n");
    }
    else{
        printf("ERROR: secret file size not encoded\n");
        return e_failure;
    }

    // Step 9 : encode_secret_file_data(encinfo) ==e_success
    // true : print the prompt message , go to the step 10 ;
    //  false : print the error return e_failure
    if(encode_secret_file_data(encInfo)==e_success)
    {
        printf("secret file data successfully\n");
    }
    else{
        printf("ERROR: Failed to encode secret file\n");
        return e_failure;
    }

    // Step 10 : call the copy remaining the data (src_fptr, dest_fptr)  ==e_success
    // true : print the prompt message , return e_success ;
    //  false : print the error return e_failure
    if (copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_dest_image)==e_success)
    {
        printf("remaining data copied successfully\n");
        return e_success;
    }
    else{
        printf("ERROR:failed to copy remaining data\n");
        return e_failure;
    }
    
}
