#include <stdio.h>
#include "decode.h"
#include "types.h"
#include<string.h>
#include "common.h"
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    char *ptr;
    ptr=strstr(argv[2],".bmp");
    //  By using the strtr function check substring is present or not char* ptr = strstr(argv[2] , ".bmp")
    
    //  if present make sure it's conatin only .bmp by using the strcmp(ptr , ".bmp") function
    // true : store into the structure member encInfo->src_image_fname = argv[2];
    if(ptr!=NULL&&strcmp(ptr,".bmp")==0)
    {
        decInfo->stego_image_fname =argv[2];
    }
    //  false : print the error message and return e_failure
    else{
        printf("ERROR: Invalid stego invalid file\n");
        return e_failure;
    }
    //check output file
    if (argv[3] != NULL)
    {
    strcpy(decInfo->output_fname, argv[3]);
    }
else
{
    strcpy(decInfo->output_fname, "output");
}
    return e_success;

}
Status open_decode_files(DecodeInfo *decInfo)
{
 // open the stego image file in read mode
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    // check whether the stego image file opened successfully
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);

        return e_failure;
    }

    // open the output file in write mode
    decInfo->fptr_output = fopen(decInfo->output_fname, "w");
    // check whether the output file opened successfully
    if (decInfo->fptr_output == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_fname);

        return e_failure;
    }


    // No failure return e_success
    return e_success;
}
//decode 1byte from lsb of 8 image bytes
Status decode_byte_from_lsb( char *image_buffer,char *data)
{
    //intialised data
    *data=0;
    //extract each lsb and construct 1byte
    for(int i=0;i<8;i++)
    {
        *data=*data<<1;
        *data=*data|(image_buffer[i]&1);
    }
    //return success
    return e_success;
}
//decode 32bit integer from lsb of 32 image bytes
Status decode_size_from_lsb(char *image_buffer, int *size)
{
    //intialize decoded size
    *size=0;
    //extract each lsb and construct integer
    for(int i=0;i<32;i++)
    {
        *size=*size<<1;
        *size=*size|(image_buffer[i]&1);
    }
    return e_success;
}
//decode and verify magic string
Status decode_magic_string(DecodeInfo *decInfo)
{
    char magic_string[3];
   // Step 1 ; char imageBuffer[8]
    char imageBuffer[8];
    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);
    // Step 2 : Generate the lopp upto the length of the magic_string
    for(int i=0;i<strlen(MAGIC_STRING);i++)
    {
    // Step 3 : Read 8 bytes of data from stego image
    fread(imageBuffer,8,1,decInfo->fptr_stego_image);
    // Step 4 : decode one character from lsb
    decode_byte_from_lsb( imageBuffer,&magic_string[i]);
    }
    //append null character
    magic_string[strlen(MAGIC_STRING)]='\0';
    //compare decoded string with orginal string
    if(strcmp(magic_string,MAGIC_STRING)==0)
    {
        return e_success;
    }
    else{
        return e_failure;
    }
} 
//decode secret file extn size
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
   // Step 1 : char imagBuffer[32];
    char imagBuffer[32];
    //  Step 2 : Read 32 bytes of data from stego image
    fread(imagBuffer,32,1,decInfo->fptr_stego_image);
    //  Step 3 : decode the extension size
    decode_size_from_lsb(imagBuffer,&decInfo->extn_size);

    // Step 5 : check whether data read successfully
    if(ftell(decInfo->fptr_stego_image)!=0)
    {

    // true : return e_success;
    return e_success;
    }
    //  false : return e_failure
    else{
        return e_failure;

    }
} 
//decode secret file extension
Status decode_secret_file_extn(DecodeInfo *decInfo)
{// Step 1 ; char imageBuffer[8]
    char imageBuffer[8];
    // Step 2 : decode each character of file extendion
    for(int i=0;i<decInfo->extn_size;i++)
    {

    // Step 3 : Read 8 bytes of data from stego image
    fread(imageBuffer,8,1,decInfo->fptr_stego_image);
    // Step 4 : decode one character from lsb
    decode_byte_from_lsb(imageBuffer,&decInfo->extn_secret_file[i]);
    }
    decInfo->extn_secret_file[decInfo->extn_size]='\0';
        return e_success;
}
Status decode_secret_file_size(DecodeInfo *decInfo)
{
     // Step 1 : char imagBuffer[32];
    char imageBuffer[32];
    //  Step 2 : Read 32 bytes of data from stego image 
    fread(imageBuffer,32,1,decInfo->fptr_stego_image);
    //  Step 3 : decode secret file size
    decode_size_from_lsb( imageBuffer,&decInfo->secret_file_size);
    printf("decoded secret file size :%d\n",decInfo->secret_file_size);
    
        return e_success;
    }

Status decode_secret_file_data(DecodeInfo *decInfo)
{
//buffer to read encoded image bytes
    char image_buffer[8];
    char ch;
    // Step 4 : decode each character of secret file
    for(int i=0;i<decInfo->secret_file_size;i++)
    {
    // Step 5 : Read 8 bytes of data from stego image
    fread(image_buffer,8,1,decInfo->fptr_stego_image);
    // Step 6 : decode one character from lsb
    decode_byte_from_lsb(image_buffer,&ch);
    // Step 7 : Write decoded character to output file
    fwrite(&ch,1,1,decInfo->fptr_output);
    }
    printf("exciting decode_secret_file_data\n");
    return e_success;}

Status do_decoding(DecodeInfo *decInfo)
    {
        if ( open_decode_files(decInfo) != e_success)
    {
        printf("ERROR: Unable to open files\n");
        return e_failure;
    }
    printf("Files opened successfully\n");

    /* Decode magic string */
    if (decode_magic_string(decInfo) != e_success)
    {
        printf("ERROR: Invalid magic string\n");
        return e_failure;
    }
    printf("Magic string decoded successfully\n");

    /* Decode extension size */
    if (decode_secret_file_extn_size(decInfo) != e_success)
    {
        printf("ERROR: Failed to decode extension size\n");
        return e_failure;
    }
    printf("Extension size decoded successfully\n");

    /* Decode extension */
    if (decode_secret_file_extn(decInfo) != e_success)
    {
        printf("ERROR: Failed to decode extension\n");
        return e_failure;
    }
    printf("Extension decoded successfully\n");

    /* Decode secret file size */
    if (decode_secret_file_size(decInfo) != e_success)
    {
        printf("ERROR: Failed to decode secret file size\n");
        return e_failure;
    }
    printf("Secret file size decoded successfully\n");

    /* Decode secret file data */
    if (decode_secret_file_data(decInfo) != e_success)
    {
        printf("ERROR: Failed to decode secret file data\n");
        return e_failure;
    }
    printf("Secret file data decoded successfully\n");

    return e_success;
    }


