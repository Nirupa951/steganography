/*
Project title:Stegonagraphy
Objective:Objective of this project is securely used to hide a secret file inside a bmp image using least significant bit  technique.
Encoded image appears visually unchanged while containing the hidden data.The hidden file can later extracted using decoding process.
Features:
1.Encode any file(.bmp,.sh,.c,.txt)
2.Decode the hidden file from steo image
3.validate command line arguments
4.check image capacity before encoding
5.Use LSB technique for data hiding
Structure:
typedef struct _EncodeInfo
{
    char *src_image_fname; // To store the src image fname
    FILE *fptr_src_image;  // To store the address of the src image
    uint image_capacity;   // To store the size of image

    char *secret_fname;       // To store the secret file name
    FILE *fptr_secret;        // To store the secret file address
    char extn_secret_file[20]; // To store the Secret file extension
    long size_secret_file;    // To store the size of the secret data
    char *dest_image_fname; // To store the dest file name
    FILE *fptr_dest_image;  // To store the address of destination image

} EncodeInfo;
 typedef struct _DecodeInfo
{
    char *stego_image_fname;
    FILE *fptr_stego_image;
    char output_fname[20];
    FILE *fptr_output;
    char extn_secret_file[20];
    int extn_size;
    int secret_file_size;
}DecodeInfo;
4.Encoding process:
1.Read command line arguments
2.open source image,secret file and output image
3.check whether image has enough capacity
4.copy bmp header
5.Encode magic string
6.Encode secret file extension size
7.Encode secret file extension
8.Encode secret file size
9.Encode secret file data
10.copy remaining image data
11.Generate stego image
5.Decoding process:
1.open stego image
2.skip BMP header
3.Decode magic string
4.Decode Extension size
5.Decode Extension
6.Decode secret file size
7.Decode secret file data
8.create output file
6.Encoding functions:
1.Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo);
2.Status do_encoding(EncodeInfo *encInfo);
3.Status open_files(EncodeInfo *encInfo);
4.Status check_capacity(EncodeInfo *encInfo);
5.uint get_image_size_for_bmp(FILE *fptr_image);
6.uint get_file_size(FILE *fptr);
7.Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image);
8.Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo);
9.Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo);
10.Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo);
11.Status encode_secret_file_size(long file_size, EncodeInfo *encInfo);
12.Status encode_secret_file_data(EncodeInfo *encInfo);
13.Status encode_byte_to_lsb(char data, char *image_buffer);
14.Status encode_size_to_lsb(int size, char *imageBuffer);
15.Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);
7.Decoding functions
1.Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);
2.Status open_decode_files(DecodeInfo *decInfo);
3.Status decode_byte_from_lsb( char *image_buffer,char *data);
4.Status decode_size_from_lsb(char *image_buffer, int *size);
5.Status decode_magic_string(DecodeInfo *decInfo);
6.Status decode_secret_file_extn_size(DecodeInfo *decInfo);
7.Status decode_secret_file_extn(DecodeInfo *decInfo);
8.Status decode_secret_file_size(DecodeInfo *decInfo);
9.Status decode_secret_file_data(DecodeInfo *decInfo);
10.Status do_decoding(DecodeInfo *decInfo);
8.compile:
encoding
/a.out -e beautiful.bmp secret.txt default.bmp
/a.out -e beautiful.bmp secret.sh default.bmp
/a.out -e beautiful.bmp secret.c default.bmp
decoding:
./a.out -d default.bmp output
9.Application:
1.Miltary communications
2.Digital watermarking
3.copyright protection
10.Advantages:
1.Supports different file types
2.Easy to decode
3.Image quality remains unchanged
11.conclusion:
This project successfully implements image steginagraphy using least significant bit technique.It securely hides secret files inside a .bmp image 
and accurately retreives thenm during decoding .Mainlu used in data hiding 



 */




#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include "decode.h"
OperationType check_operation_type(char *);

     // Step 1 : argc >= 4 true : go to the step 2
     // false : Print the error message and terminate
     // Step 2 :  Call the check_operation_type(argv[1]) == e_encode
     // true : print user selected the encoding part , go to the step 3
     // Step 3 : Declare the structure variable Encodeinfo encinfo;
     // Step 4 : call the  read_and_validate_encode_args(argv , &encinfo ) == e_success
     // true : Go to the step 5;
     // false : return e_failure
     // Step 5 : Call the do_encoding function (&encinfo) == e_success
      // true : print the prompt message ;
     // false : return e_failure
int main(int argc, char *argv[])
{
  if(argc<2)
  {
    printf("Not enough arguments\n");
    printf("./a.out -e beautiful.bmp secret.txt");
    printf("./a.out -d <stego.bmp> [output_file]\n");
    return e_failure;
  }
OperationType op= check_operation_type(argv[1]);
if(op == e_encode)
{
     if(argc<4)
     {
     printf("Not enough arguments for encoding\n");
    printf("./a.out -d <stego.bmp> [output_file]\n");
    return e_failure;
  }
    printf("Encoding selected\n");

    EncodeInfo encInfo;

    if(read_and_validate_encode_args(argv, &encInfo) == e_success)
    {
        printf("Arguments validated\n");

        if(do_encoding(&encInfo) == e_success)
        {
            printf("Encoding completed successfully\n");
        }
        else
        {
            printf("Encoding failed\n");
            return e_failure;
        }
    }
    else
    {
        printf("Invalid encode arguments\n");
        return e_failure;
    }
}
else if(op == e_decode)
{
     if (argc < 3)
        {
            printf("Not enough arguments for decoding\n");
            printf("Usage: ./a.out -d <stego.bmp> [output_file]\n");
            return e_failure;
        }
        printf("decoding selected");
    DecodeInfo decInfo;

    if(read_and_validate_decode_args(argv, &decInfo) == e_success)
    {
        if(do_decoding(&decInfo) == e_success)
        {
            printf("Decoding completed successfully\n");
        }
        else
        {
            printf("Decoding failed\n");
            return e_failure;
        }
     }
    }
else
{
    printf("Unsupported operation\n");
     printf("Usage:\n");
     printf("./a.out -e <source.bmp> <secret.txt> [output.bmp]\n");
     printf("./a.out -d <stego.bmp> [output_file]\n");
     return e_failure;
}
return e_success;
}
     OperationType check_operation_type(char *symbol)
     {
          // Step 1 : check whether ths symbol is having -e or not
          // true : return e_encode
          // false : go to step 2 :
          // Step 2 : check whether ths symbol is having -d or not
          // true : return e_decode
          // false : return e_unsupported
if(strcmp(symbol,"-e")==0)
{
    return e_encode;
}
    else if(strcmp(symbol,"-d")==0)
    {
    return e_decode;
    }
    else
    {
    return e_unsupported;
}
     }
